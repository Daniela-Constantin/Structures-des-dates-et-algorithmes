#include <iostream>
#include "tas.h"
#include <fstream>
#include <conio.h>
#include <stdlib.h>
using namespace std;

int main()
{
    ifstream f("date.in");
    Employe x;
    int t;

    Heap<Employe> heap(100);

    while(f>>x.nom>>x.prenom>>x.s_base>>x.s_total>>x.exp)
        heap.insertElement(x);
    heap.updateS_Total();
    ///heap.Affichage_par_Niveau();

    do
    {
        system("cls");
        cout<<"1.Entreprise entiere ou non"<<endl;
        cout<<"2.Changer Manager"<<endl;
        cout<<"3.Le plus proche ancetre commun"<<endl<<endl;
        cout<<"Tapez le nombre de l'instruction: ";
        cin>>t;
        cout<<endl;
        switch (t)
        {

            case 1:
            {
                if(heap.entier()==0)
                    cout<<"L'entreprise n'est pas entiere"<<endl;
                else
                    cout<<"L'entreprise est entiere"<<endl;
            }
            getch(); break;

            case 2:
            {
                heap.extractMax();
            }
            getch(); break;

            case 3:
            {
                int x,y;
                cout<<"Introduissez les annes d'experience des deux employes: ";
                cin>>x>>y; ///anii de experienta
                int i=1,j=1;
                while(heap.H[i].exp!=x)
                    i++;
                while(heap.H[j].exp!=y)
                    j++;
                int p=heap.patron(i,j);
                cout<<"Le patron commun est: "<<heap.H[p].nom<<" "<<heap.H[p].prenom<<", avec "<<heap.H[p].exp<<" annees d'experience.";
            }
            getch(); break;
        }
    }while(t!=0);
    return 0;
}
