#ifndef TAS_H_INCLUDED
#define TAS_H_INCLUDED

#include <stdio.h>
#include <iostream>
#include <math.h>

using namespace std;

struct Employe
{
    string nom;
    string prenom;
    float s_base;
    float s_total;
    int exp;
};

template <typename T> class Heap
{
    public:
        Employe *H;
        int currentDim, maxDim;

        Heap(int maxDim)
        {
            this->maxDim = maxDim;
            H = new Employe[this->maxDim + 1];
            currentDim = 0;
        }

        void insertElement(Employe x)
        {
            if (currentDim == maxDim)
            {
                cout<<"Eroare";
                return;
            }
            currentDim++;
            H[currentDim].nom = x.nom;
            H[currentDim].prenom = x.prenom;
            H[currentDim].s_base = x.s_base;
            H[currentDim].s_total = x.s_total;
            H[currentDim].exp = x.exp;
            filterUp(currentDim);
        }

        void updateS_Total()
        {
            for(int i=currentDim;i>=1;i--)
            {
                if(calc_niv(i)==no_niveaux())
                    H[i].s_base=1000;
                else
                    H[i].s_base=H[i*2].s_base*2;
                H[i].s_total=H[i].s_base;
                if(i*2<=currentDim)
                    H[i].s_total+=H[i*2].s_total/10;
                if(i*2+1<=currentDim)
                    H[i].s_total+=H[i*2+1].s_total/10;
            }
        }

        ///sub d) prima instructiune
        int entier()
        {
            for(int i=1;i<=currentDim;i++)
                if(no_fils(i)==1)
                    return 0;
            return 1;
        }

        int no_fils(int i)
        {
            int no=0;
            if(i*2<=currentDim)
                no++;
            if(i*2+1<=currentDim)
                no++;
            return no;
        }

        ///fonction qui efface et affiche le plus grand element (la racine)
		void extractMax()
		{
            if (currentDim == 0)
                cout<<"Eroare";

            cout<<"On a efface le manager: "<<H[1].nom<<" "<<H[1].prenom<<endl<<endl;
            H[1].nom = H[currentDim].nom;
            H[1].prenom = H[currentDim].prenom;
            H[1].s_base = H[currentDim].s_base;
            H[1].s_total = H[currentDim].s_total;
            H[1].exp = H[currentDim].exp;
            currentDim--;
			if (currentDim > 0)
            {
                filterDown(1);
                updateS_Total();
            }
            Affichage_par_Niveau();
        }

        void filterUp(int i)
        {
            int parent;
            Employe vaux;

            parent = i / 2;
            while (i > 1 && H[parent].exp < H[i].exp)
            {
                vaux.nom = H[parent].nom;
                vaux.prenom=H[parent].prenom;
                vaux.s_base=H[parent].s_base;
                vaux.s_total=H[parent].s_total;
                vaux.exp=H[parent].exp;

                H[parent].nom = H[i].nom;
                H[parent].prenom=H[i].prenom;
                H[parent].s_base=H[i].s_base;
                H[parent].s_total=H[i].s_total;
                H[parent].exp=H[i].exp;

                H[i].nom = vaux.nom;
                H[i].prenom = vaux.prenom;
                H[i].s_base = vaux.s_base;
                H[i].s_total = vaux.s_total;
                H[i].exp = vaux.exp;

                i = parent;
                parent = i / 2;
            }
        }

        ///fonction appelle par la fonction d'effacement pour maintenir les proprietes du heap
         void filterDown(int i)
         {
            Employe vaux;

            while (1) {
                if (2 * i + 1 > currentDim)
                    {
                        if (2 * i > currentDim)
                            break;
                        else
                    ///Si on a un seul enfant
                        if (H[2 * i].exp > H[i].exp)
                        {
                            vaux.nom = H[2 * i].nom;
                            vaux.prenom = H[2 * i].prenom;
                            vaux.s_base = H[2 * i].s_base;
                            vaux.s_total = H[2 * i].s_total;
                            vaux.exp = H[2 * i].exp;

                            H[2 * i].nom = H[i].nom;
                            H[2 * i].prenom = H[i].prenom;
                            H[2 * i].s_base = H[i].s_base;
                            H[2 * i].s_total = H[i].s_total;
                            H[2 * i].exp = H[i].exp;

                            H[i].nom = vaux.nom;
                            H[i].prenom = vaux.prenom;
                            H[i].s_base = vaux.s_base;
                            H[i].s_total = vaux.s_total;
                            H[i].exp = vaux.exp;

                            i = 2 * i;
                        }
                        else
                            break;
                    }
                    else
                    {
                        ///Voir lequel des enfants est le plus grand
                    if (H[2 * i].exp >= H[2 * i + 1].exp && H[2 * i].exp > H[i].exp)
                    {
                        vaux.nom = H[2 * i].nom;
                        vaux.prenom = H[2 * i].prenom;
                        vaux.s_base = H[2 * i].s_base;
                        vaux.s_total = H[2 * i].s_total;
                        vaux.exp = H[2 * i].exp;

                        H[2 * i].nom = H[i].nom;
                        H[2 * i].prenom = H[i].prenom;
                        H[2 * i].s_base = H[i].s_base;
                        H[2 * i].s_total = H[i].s_total;
                        H[2 * i].exp = H[i].exp;

                        H[i].nom = vaux.nom;
                        H[i].prenom = vaux.prenom;
                        H[i].s_base = vaux.s_base;
                        H[i].s_total = vaux.s_total;
                        H[i].exp = vaux.exp;

                        i = 2 * i;
                    }
                    else
                    if (H[2 * i + 1].exp >= H[2 * i].exp && H[2 * i + 1].exp > H[i].exp)
                    {
                        vaux.nom = H[2 * i + 1].nom;
                        vaux.prenom = H[2 * i + 1].prenom;
                        vaux.s_base = H[2 * i + 1].s_base;
                        vaux.s_total = H[2 * i + 1].s_total;
                        vaux.exp = H[2 * i + 1].exp;

                        H[2 * i + 1].nom = H[i].nom;
                        H[2 * i + 1].prenom = H[i].prenom;
                        H[2 * i + 1].s_base = H[i].s_base;
                        H[2 * i + 1].s_total = H[i].s_total;
                        H[2 * i + 1].exp = H[i].exp;

                        H[i].nom = vaux.nom;
                        H[i].prenom = vaux.prenom;
                        H[i].s_base = vaux.s_base;
                        H[i].s_total = vaux.s_total;
                        H[i].exp = vaux.exp;

                        i = 2 * i + 1;
                    }
                    else
                        break;
                }
            }
        }

        int patron(int i, int j)
        {
            while(i!=j)
            {
                if(calc_niv(i)==calc_niv(j))
                {
                    i=i/2;
                    j=j/2;
                }
                else
                    if(calc_niv(i)<calc_niv(j))
                        j=j/2;
                    else
                        i=i/2;
            }
            return i;
        }

        ///calc cate niveluri am in total
        int no_niveaux()
        {
            int s=0;
            while(pow(2,s)<currentDim)
                s++;
            return s-1;
        }

        ///returneaza nivelul pozitiei pe care o introduc
        int calc_niv(int i)
        {
            int p=0;
            while(pow(2,p)<=i)
                p++;
            return p-1;
        }

        void Affichage_par_Niveau()
        {
            int i=1;
            int niv=no_niveaux();
            int n=0;
            while(n<=niv)
            {
                cout<<"Sur le niveau numero "<<n<<" on a:"<<endl;
                for(int j=i;j<pow(2,n+1);j++)
                    if(j<=currentDim)
                        cout<<"       "<<H[j].nom<<" "<<H[j].prenom<<" "<<H[j].s_base<<" "<<H[j].s_total<<" "<<H[j].exp<<endl;
                cout<<endl;
                n++;
                i=pow(2,n);
            }
        }
};


#endif // TAS_H_INCLUDED
