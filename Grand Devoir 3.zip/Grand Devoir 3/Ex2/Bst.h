#include <stdio.h>
#include <iostream>
#include <math.h>
#include <algorithm>
#include "Queue.h"
#include <queue>

using namespace std;

template<typename T> class BinarySearchTree {
    public:
        BinarySearchTree<T> *root, *left_son, *right_son, *parent;
        T *pinfo;

        BinarySearchTree()
        {
            left_son = right_son = NULL;
            root = this;
            pinfo = NULL;
            parent = NULL;
        }

        void setInfo(T info)
        {
            pinfo = new T;
            *pinfo = info;
        }

        void insert(T x)
        {
            if (pinfo == NULL)
                setInfo(x);
            else
                insert_rec(x);
        }

        void insert_rec(T x)
        {
            int next_son;
			if (x <= (*pinfo))
                next_son = 0;
            else
                next_son = 1;

            if (next_son == 0)
            {
                if (left_son == NULL)
                {

                    left_son = new BinarySearchTree<T>;
                    left_son->pinfo = new T;
                    *(left_son->pinfo) = x;

                    left_son->left_son = left_son->right_son = NULL;
                    left_son->parent = this;
                    left_son->root = root;
                }
                else
                    left_son->insert_rec(x);
            }
            else
            {
                if (right_son == NULL)
                {
                    right_son = new BinarySearchTree<T>;
                    right_son->pinfo = new T;
                    *(right_son->pinfo) = x;

                    right_son->left_son = right_son->right_son = NULL;
                    right_son->parent = this;
                    right_son->root = root;
                }
                else
                    right_son->insert_rec(x);
            }
        }

		BinarySearchTree<T>* find(T x)
		{
            BinarySearchTree<T> *rez;

            if (pinfo == NULL)
                return NULL;

            if ((*pinfo) == x)
                return this;

            if (x <= (*pinfo))
            {
                if (left_son != NULL)
                    return left_son->find(x);
                else
                    return NULL;
            }
            else
            {
                if (right_son != NULL)
                    return right_son->find(x);
                else
                    return NULL;
            }
        }

        void removeInfo(T x)
        {
            BinarySearchTree<T> *t = find(x);
            if (t != NULL)
                t->remove();
        }

		void remove() {
            BinarySearchTree<T> *p;
            T *paux;

            if (left_son == NULL && right_son == NULL)
            {
                if (parent == NULL)
                {
                    delete this->pinfo;
                    root->pinfo = NULL;
                } else
                {
                    if (parent->left_son == this)
                        parent->left_son = NULL;
                    else
                        parent->right_son = NULL;

                    delete this->pinfo;
                    delete this;
                }
            }
            else
            {
                if (left_son != NULL)
                {
                    p = left_son;
                    while (p->right_son != NULL)
                        p = p->right_son;
                }
                else
                {
                    p = right_son;
                    while (p->left_son != NULL)
                        p = p->left_son;
                }

                paux = p->pinfo;
                p->pinfo = this->pinfo;
                this->pinfo = paux;

                p->remove();
            }
        }

        void inOrderTraversal()
        {
            if (left_son != NULL)
                left_son->inOrderTraversal();

            cout<< *pinfo<<" ";

            if (right_son != NULL)
                right_son->inOrderTraversal();
        }

        void minimum()
        {
            BinarySearchTree <T> *p;
            p=root;
            while(p->left_son!=NULL)
                p=p->left_son;
            cout<<"Le minimum est: "<<*(p->pinfo);
        }

        void affichage_par_niveau_2()
        {
            int i=0;
            cout<<"Niveau "<<i<<": ";

            Queue <BinarySearchTree*> currentLevel,nextLevel;
            currentLevel.enqueue(root);

            while(!currentLevel.isEmpty())
            {
                BinarySearchTree *currNode=currentLevel.peek();
                currentLevel.dequeue();

                if(currNode)
                {
                    cout<<*currNode->pinfo<<" ";
                    if(currNode->left_son!=NULL)
                        nextLevel.enqueue(currNode->left_son);
                    if(currNode->right_son!=NULL)
                        nextLevel.enqueue(currNode->right_son);
                }

                if(currentLevel.isEmpty() && !nextLevel.isEmpty())
                {
                    i++;
                    cout<<endl;
                    cout<<"Niveau "<<i<<": ";
                    swap(currentLevel,nextLevel);
                }
            }
        }

//        void affichage_par_niveau_1()
//        {
//
//            queue <BinarySearchTree*> q;
//
//            q.push(root);
//            int i=-1;
//
//            while (1)
//            {
//                int nodeCount = q.size();
//
//                if (nodeCount == 0)
//                    break;
//                else
//                {
//                    i++;
//                    cout<<"Niveau "<<i<<": ";
//                }
//
//                while (nodeCount > 0)
//                {
//                    BinarySearchTree* node = q.front();
//                    cout << *node->pinfo <<" ";
//                    q.pop();
//                    if (node->left_son != NULL)
//                        q.push(node->left_son);
//                    if (node->right_son != NULL)
//                        q.push(node->right_son);
//                    nodeCount--;
//                }
//                cout << endl;
//            }
//        }

        void grand_fils(char c)
        {
            BinarySearchTree<T> *poz=find(c);
            if(poz==root)
                cout<<"Non!"<<endl;
            else
            {
                BinarySearchTree<T> *per=poz->parent;
                BinarySearchTree<T> *gper=per->parent;
                if(per!=NULL && gper!=NULL)
                    cout<<"Oui! Pere= "<<*per->pinfo<<", grand-pere= "<<*gper->pinfo<<endl;
                else
                    cout<<"Non!"<<endl;
            }

        }

        int parcours(int &nr)
        {
            nr++;
            if (left_son != NULL)
                left_son->parcours(nr);
            if (right_son != NULL)
                right_son->parcours(nr);
            return nr;
        }


        int no_fils(BinarySearchTree<T> *p)
        {
            int nr=0;
            if(p->left_son!=NULL)
                nr++;
            if(p->right_son!=NULL)
                nr++;
            return nr;
        }

        int parfait()
        {
            Queue <BinarySearchTree*> currentLevel,nextLevel;
            currentLevel.enqueue(root);

            while(!currentLevel.isEmpty())
            {
                BinarySearchTree *currNode1=currentLevel.peek();
                currentLevel.dequeue();

                if(!currentLevel.isEmpty())
                {
                    BinarySearchTree *currNode2=currentLevel.peek();
                    if((currNode1->no_fils(currNode1)==0 && currNode2->no_fils(currNode2)!=0)||(currNode1->no_fils(currNode1)!=0 && currNode2->no_fils(currNode2)==0))
                        return 0;
                }

                if(currNode1)
                {
                    if(currNode1->left_son!=NULL)
                        nextLevel.enqueue(currNode1->left_son);
                    if(currNode1->right_son!=NULL)
                        nextLevel.enqueue(currNode1->right_son);
                }

                if(currentLevel.isEmpty() && !nextLevel.isEmpty())
                    swap(currentLevel,nextLevel);
            }
            return 1;
        }
};








