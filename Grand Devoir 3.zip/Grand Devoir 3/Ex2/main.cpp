#include <iostream>
#include "Bst.h"
using namespace std;

int main()
{
    char x;
    BinarySearchTree<char> *r = new BinarySearchTree<char>;

    cout<<"Introduissez les valeurs de l'arbre:"<<endl;
    cin>>x;
    while(x>=65 && x<=90)
    {
        r->insert(x);
        cin>>x;
    }

    cout<<"Affichage a l'aide de deux filles d'attente: "<<endl;
    r->affichage_par_niveau_2();
    cout<<endl<<endl;

//    cout<<"Affichage a l'aide d'une seule fille d'attente: "<<endl;
//    r->affichage_par_niveau_1();
//    cout<<endl;

    cout<<"Fils a verifier: ";
    cin>>x;
    r->grand_fils(x);

    int i=0;
    cout<<endl<<"Nombre d'elements= "<<r->parcours(i)<<endl<<endl;

    if(r->parfait()==0)
        cout<<"L'arbre n'est pas parfait";
    else
        cout<<"L'arbre est parfait";

    return 0;
}
