#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED

#include <stdio.h>
#include <iostream>
#define NMAX 100

using namespace std;
template<typename T> class Queue {
    private:
        T queueArray[NMAX];
        int head, tail;
    public:

        void enqueue(T x) {
            if (tail == NMAX) {
                cout<<"The queue is full!";
                return;
            }
            queueArray[tail] = x;
            tail++;
        }

        int getTail()
        {
            return tail;
        }

        T dequeue() {
            if (isEmpty()) {
                cout<<"The queue is empty!";
                T x;
                return x;
            }
            T x = queueArray[head];
            head++;
            return x;   }

        T peek() {
            if (isEmpty()) {
                cout<<"The queue is empty!";
                T x;
                return x;
            }
            return queueArray[head];
        }

        int isEmpty() {
            return (head == tail);
        }

    Queue() {
        head = tail = 0;
    }
};


#endif // QUEUE_H_INCLUDED
