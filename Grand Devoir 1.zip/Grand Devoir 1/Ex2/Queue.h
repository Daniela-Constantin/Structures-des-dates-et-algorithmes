#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED

#include <iostream>
using namespace std;

#define NMAX 100
template <typename T> class Queue
{
    private:
        T queueArray[NMAX];
        int head, tail, size;
    public:
        int getHead()
        {
            return head;
        }

        int getTail()
        {
            return tail;
        }

        void enqueue(T x)
        {
            if (size == NMAX)
            {
                cout<<"The queue is full!\n";
                return;
            }
            queueArray[tail] = x;
            tail = (tail + 1) % NMAX;
            size++;
        }

        T dequeue()
        {
            if (isEmpty())
            {
                cout<<"The queue is empty!\n";
                T x;
                return x;
            }
            T x = queueArray[head];
            head = (head + 1) % NMAX;
            size--;
            return x;
        }

        T peek()
        {
            if (isEmpty())
            {
                cout<<"The queue is empty!\n";
                T x;
                return x;
            }
            return queueArray[head];
        }

        int isEmpty()
        {
            return (size == 0);
        }

        Queue()
        {
            head = tail = size = 0;
        }

        void affichage()
        {
            for(int i=head;i<tail;i++)
                cout<<queueArray[i]<<" ";
            cout<<endl;
        }
};


#endif // QUEUE_H_INCLUDED
