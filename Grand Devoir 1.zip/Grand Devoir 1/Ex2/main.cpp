#include <iostream>
#include "Queue.h"
using namespace std;

Queue <int> q;
Queue <int> qarr;

void ecriture(int n, int &v)
{
    int a=1,i=0;
    while(a<n)
    {
        a=a*2;
        i++;
    }
    a=a/2;
    cout<<"On peut ecrire "<<n<<" comme: 2^"<<i-1<<"+"<<n-a<<endl;
    v=2*(n-a)+1;
}

void arranger(int s,int m)
{
    int x;
    if(m!=0)
    {
            while(q.peek()!=m)
        {
            x=q.peek();
            q.dequeue();
            q.enqueue(x);
        }
        while(q.isEmpty()!=1)
        {
            x=q.peek();
            q.dequeue();
            qarr.enqueue(x);
        }
    }
    else
        while(q.isEmpty()!=1)
        {
            x=q.peek();
            q.dequeue();
            qarr.enqueue(x);
        }
}

void voler()
{
    int i=0,x;
    while(qarr.getTail()-qarr.getHead()!=1)
        {
            i++;
            if(i==1)
                cout<<i<<"er vol"<<endl;
            else
                cout<<i<<"eme vol"<<endl;
            x=qarr.peek();
            qarr.dequeue();
            cout<<"La maison no. "<<x<<" a ete sautee. ";
            cout<<"La maison no. "<<qarr.peek()<<" a ete volee."<<endl;
            qarr.enqueue(x);
            qarr.dequeue();
            cout<<"Les maisons apres le vol: ";
            qarr.affichage();
            cout<<endl;
        }
}

int main()
{
    int n,v=0,s,m;
    cout<<"Le nombre des maisons est: ";
    cin>>n;

    for(int i=0;i<n;i++)
        q.enqueue(i+1);

    cout<<"Voici les maisons avec leurs numeros: ";
    q.affichage();
    cout<<endl;

    cout<<"La maison qu'on veut sauver est: ";
    cin>>s;

    ecriture(n,v);
    cout<<"Pour ne pas etre volee, la maison choisie doit etre la "<<v<<"ieme dans le parcours de Robin Hood"<<endl;

    m=s-v;
    if(m<0)
        m=n-v+s+1;

    //if(m!=0)
        arranger(s,m);
    //else
        cout<<"La maison est deja bien placee"<<endl;

    cout<<"Pour tromper Robin Hood, il doit commencer le vol avec la maison no. "<<qarr.peek()<<endl<<endl;
    cout<<"Commencons le vol:"<<endl;
    voler();

    return 0;
}
