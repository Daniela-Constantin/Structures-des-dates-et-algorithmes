#ifndef STACK5_H_INCLUDED
#define STACK5_H_INCLUDED

#include <iostream>
using namespace std;

#define NMAX 5

template <typename T> class Stack5
{
    private:
        T stackArray[NMAX];
        int topLevel;
    public:
        void push(T x)
        {
            if (topLevel >= NMAX-1)
            {
                cout<<"The stack5 is full: we have already NMAX elements!\n";
                return;
            }
            stackArray[++topLevel] = x;
        }

        int isEmpty()
        {
         return (topLevel < 0);
        }

        int isFull()
        {
            if(topLevel==4)
                return 1;
            return 0;
        }

        int getTopLevel()
        {
            return topLevel;
        }

        T pop()
        {
            if (isEmpty())
            {
                cout<<"The stack5 is empty! \n";
                T x;
                return x;
            }
            return stackArray[topLevel--];
        }

        T peek()
        {
            if (isEmpty())
            {
                cout<<"The stack is empty! \n";
                T x;
                return x;
            }
            return stackArray[topLevel];
        }

        void affichage()
        {
            cout<<"Galeata de 5L contine: ";
            cout<<topLevel+1<<" L";
            cout<<endl;
        }

        Stack5()
        {
            topLevel = -1;
        }

        ~Stack5() {}
};

#endif // STACK5_H_INCLUDED
