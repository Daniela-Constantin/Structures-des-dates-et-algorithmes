#ifndef STACK20_H_INCLUDED
#define STACK20_H_INCLUDED

#include <iostream>
using namespace std;

#define NMAX 20

template <typename T> class Stack20
{
    private:
        T stackArray[NMAX];
        int topLevel;
    public:
        void push(T x)
        {
            if (topLevel >= NMAX-1)
            {
                cout<<"The stack20 is full: we have already NMAX elements!\n";
                return;
            }
            stackArray[++topLevel] = x;
        }

        int isEmpty()
        {
         return (topLevel < 0);
        }

        int isFull()
        {
            if(topLevel==19)
                return 1;
            return 0;
        }

        int getTopLevel()
        {
            return topLevel;
        }

        T pop()
        {
            if (isEmpty())
            {
                cout<<"The stack20 is empty! \n";
                T x;
                return x;
            }
            return stackArray[topLevel--];
        }

        T peek()
        {
            if (isEmpty())
            {
                cout<<"The stack is empty! \n";
                T x;
                return x;
            }
            return stackArray[topLevel];
        }

        void affichage()
        {
            cout<<"Butoiul contine: ";
            cout<<topLevel+1<<" L";
            cout<<endl;
        }

        Stack20()
        {
            topLevel = -1;
        }

        ~Stack20() {}
};

#endif // STACK20_H_INCLUDED
