#include <iostream>
#include "Stack20.h"
#include "Stack8.h"
#include "Stack5.h"

using namespace std;

int main()
{
    int n=1;
    Stack20 <int> s20;
    Stack8 <int> s8;
    Stack5 <int> s5;

    //E1-UMPLEM BUTOIUL CU 20 DE UNITATI (20L DE VIN), CA IN CERINTA
    cout<<"PRIMA ETAPA"<<endl;
    while(s20.isFull()!=1)
        s20.push(1);

    s20.affichage();
    s8.affichage();
    s5.affichage();
    cout<<endl;

    //EFECTUAM ACEST LOOP PANA CAND NE RAMANE 1 UNITATE (1L DE VIN) IN GALEATA DE 8 LITRII
    while(s8.getTopLevel()!=0)
    {
        //E2-TURNAM DIN BUTOIUL CU VIN IN CEA MAI MARE GALEATA
        while(s8.isFull()!=1)
        {
            s8.push(1);
            s20.pop();
        }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;

        //E3-UMPLEM A DOUA GALEATA CU VINUL DIN PRIMA
        while(s5.isFull()!=1)
        {
            s5.push(1);
            s8.pop();
        }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;

        //E4-GOLIM A DOUA GALEATA IN BUTOI
        while(s5.isEmpty()!=1)
        {
            s5.pop();
            s20.push(1);
        }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;

        //E5-TRANSFERAM CE A MAI RAMAS IN PRIMA GALEATA IN CEA DE-A DOUA
        while(s5.isFull()!=1 && s8.isEmpty()!=1)
            {
                s8.pop();
                s5.push(1);
            }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;
    }

    //IN MOMENTUL DE FATA, GALEATA DE 8 LITRII CONTINE 1L DE VIN SI DIN ACEST PUNCT SE SCHIMBA ORDINEA ETAPELOR
    while(s8.getTopLevel()!=3)
    {
        //E4-GOLIM A DOUA GALEATA IN BUTOI
        while(s5.isEmpty()!=1)
        {
            s5.pop();
            s20.push(1);
        }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;

        //E3-UMPLEM A DOUA GALEATA CU VINUL DIN PRIMA
        while(s5.isFull()!=1 && s8.isEmpty()!=1)
        {
            s5.push(1);
            s8.pop();
        }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;

        //E2-TURNAM DIN BUTOIUL CU VIN IN CEA MAI MARE GALEATA
        while(s8.isFull()!=1)
        {
            s8.push(1);
            s20.pop();
        }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;

        //E5-TRANSFERAM CE A MAI RAMAS IN PRIMA GALEATA IN CEA DE-A DOUA
        while(s5.isFull()!=1 && s8.isEmpty()!=1)
            {
                s8.pop();
                s5.push(1);
            }
        n++;
        cout<<"A "<<n<<"-A ETAPA"<<endl;
        s20.affichage();
        s8.affichage();
        s5.affichage();
        cout<<endl;
    }

    return 0;
}
