#ifndef STACK8_H_INCLUDED
#define STACK8_H_INCLUDED

#include <iostream>
using namespace std;

#define NMAX 8

template <typename T> class Stack8
{
    private:
        T stackArray[NMAX];
        int topLevel;
    public:
        void push(T x)
        {
            if (topLevel >= NMAX-1)
            {
                cout<<"The stack8 is full: we have already NMAX elements!\n";
                return;
            }
            stackArray[++topLevel] = x;
        }

        int isEmpty()
        {
         return (topLevel < 0);
        }

        int isFull()
        {
            if(topLevel==7)
                return 1;
            return 0;
        }

        int getTopLevel()
        {
            return topLevel;
        }

        T pop()
        {
            if (isEmpty())
            {
                cout<<"The stack8 is empty! \n";
                T x;
                return x;
            }
            return stackArray[topLevel--];
        }

        T peek()
        {
            if (isEmpty())
            {
                cout<<"The stack is empty! \n";
                T x;
                return x;
            }
            return stackArray[topLevel];
        }

        void affichage()
        {
            cout<<"Galeata de 8L contine: ";
            cout<<topLevel+1<<" L";
            cout<<endl;
        }

        Stack8()
        {
            topLevel = -1;
        }

        ~Stack8() {}
};

#endif // STACK8_H_INCLUDED
