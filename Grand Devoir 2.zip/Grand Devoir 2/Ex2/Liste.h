#ifndef LISTE_H_INCLUDED
#define LISTE_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>

using namespace std;

struct Point
{
    int coord_x, coord_y;
};

template <typename T>
struct Noeud
{
    Point info;
    Noeud <T> *next;
    Noeud <T> *prev;
};

template <typename T>
class Liste
{
    public:
        Noeud <T> *pfirst;
        Noeud <T> *plast;

    void addFirst(Point p)
    {
        Noeud <T> *paux;
        paux = new Noeud<T>;

        paux->info.coord_x = p.coord_x;
        paux->info.coord_y = p.coord_y;
        paux->prev = NULL;
        paux->next = pfirst;

        if (pfirst != NULL)
            pfirst->prev = paux;

        pfirst = paux;

        if (plast==NULL)
            plast=pfirst;
    }

    void addLast(Point p)
    {
        Noeud<T> *paux;

        paux = new Noeud <T>;
        paux->info.coord_x = p.coord_x;
        paux->info.coord_y = p.coord_y;
        paux->prev = plast;
        paux->next = NULL;

        if (plast != NULL)
            plast->next = paux;

        plast = paux;

        if (pfirst == NULL)
            pfirst = plast;
    }

    int getInfoX (Noeud<T>* p)
    {
        return p->info.coord_x;
    }

    int getInfoY (Noeud<T>* p)
    {
        return p->info.coord_y;
    }

    int isEmpty()
    {
        return (pfirst == NULL);
    }

    Liste()
    {
        pfirst = plast = NULL;
    }

    void printList()
    {
        Noeud <T> *i;
        i=pfirst;
        while(i!=NULL)
        {
            cout<<i->info.coord_x<<" "<<i->info.coord_y<<endl;
            i=i->next;
        }
    }

    double calc_dist(Noeud<T>* p)
    {
        return pow(p->info.coord_x,2)+pow(p->info.coord_y,2);
    }

    int calc_det(Noeud <T> *i, Noeud <T> *j, Noeud <T> *k)
    {
        return (i->info.coord_x*j->info.coord_y+j->info.coord_x*k->info.coord_y+i->info.coord_y*k->info.coord_x)-(j->info.coord_y*k->info.coord_x+k->info.coord_y*i->info.coord_x+j->info.coord_x*i->info.coord_y);
    }

    void Sort()
    {
        Noeud <T> *i;
        Noeud <T> *j;
        int aux;
        i=pfirst;
        while(i->next!=NULL)
        {
            j=i->next;
            while(j!=NULL)
            {
                if(calc_dist(j)<calc_dist(i))
                {
                    aux=i->info.coord_x;
                    i->info.coord_x=j->info.coord_x;
                    j->info.coord_x=aux;
                    aux=i->info.coord_y;
                    i->info.coord_y=j->info.coord_y;
                    j->info.coord_y=aux;
                    j=j->prev;
                }
                j=j->next;
            }
            i=i->next;
        }
    }

};

#endif // LISTE_H_INCLUDED
