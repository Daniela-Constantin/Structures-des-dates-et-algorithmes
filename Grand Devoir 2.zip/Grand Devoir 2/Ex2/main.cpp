#include <iostream>
#include "Liste.h"
using namespace std;

int main()
{
    Liste <int> myListe;
    int n,d;
    Point i;
    Noeud <int>* j;
    cout<<"The number of points is: ";
    cin>>n;

    for(int k=0;k<n;k++)
    {
        cout<<"The coordonates for the "<<k+1<<" point are (ox, then oy): ";
        cin>>i.coord_x>>i.coord_y;
        myListe.addLast(i);
    }

    cout<<"My list is:"<<endl;
    myListe.printList();

    cout<<endl<<"The distance between each point and the origin is:"<<endl;
    j=myListe.pfirst;
    while(j!=NULL)
    {
        cout<<myListe.calc_dist(j)<<" ";
        j=j->next;
    }

    myListe.Sort();
    cout<<endl<<endl<<"My list after sorting is:"<<endl;
    myListe.printList();


    cout<<endl<<"The distance between each point and the origin (after sorting) is:"<<endl;
    j=myListe.pfirst;
    while(j!=NULL)
    {
        cout<<myListe.calc_dist(j)<<" ";
        j=j->next;
    }

    cout<<endl<<endl;
    j=myListe.pfirst;
    while(j->next->next!=NULL)
    {
        d=myListe.calc_det(j,j->next,j->next->next);
        if(d!=0)
        {
            cout<<"The points are not collinear.";
            break;
        }
        j=j->next;
    }

    if(j->next->next==NULL)
       cout<<"The points are collinear.";
    return 0;
}
