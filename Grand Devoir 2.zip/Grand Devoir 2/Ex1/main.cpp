#include <iostream>
#include <fstream>
#include "Graphe.h"
using namespace std;

//POUR LE VECTEUR QUI RETIENT LES VOITURES QUI ONT BESOIN D'UNE STATION SERVICE
struct voiture
{
    string ville;
    unsigned int gaz;
    unsigned int cons;
};

int main()
{
    ifstream f("date.in");
    int nv,na; //NOMBRE VILLES, NOMBRE AUTOROUTES
    f>>nv>>na;
    Graph<string, int> g(nv);

    int i,j,k,max=0,maxi;
    string a,v1,v2;
    char* ss;

    cout<<"Le nombre des villes est: ";
    cout<<nv<<endl<<"Le nombre des autoroutes est: ";
    cout<<na<<endl;

    //ON CREE LA LISTE DES VILLES
    for(i=0;i<nv;i++)
    {
        f>>a;
        g.setNodeInfo(i,a);
    }

    cout<<endl<<"Les villes sont: ";
    for(i=0;i<nv;i++)
    {
        cout<<g.getNodeInfo(i)<<" ";
    }
    cout<<endl<<endl;

    //ON AJOUTE LES AUTOROUTES A NOTRE LISTE DES VILLES
    for(i=0;i<na;i++)
    {
        f>>v1>>v2; //LES 2 VILLES ENTRE LESQUELS ON A UNE AUTOROUTE
        j=0;k=0;
        while(g.getNodeInfo(j)!=v1)
            j++;
        while(g.getNodeInfo(k)!=v2)
            k++;
        g.addEdge(j,k);
    }

    //A
    //A L'AIDE DE LA METHODE Grad ON PEUT DETERMINER LE NOMBRES DES AUTOROUTES ENTRANTES DANS CHAQUE VILLE
    for(i=0;i<nv;i++)
        {
            if(g.Grad(i)>max)
            {
                max=g.Grad(i);
                maxi=i;
            }
        }

    cout<<"La plus superpeuplee ville est: "<<g.getNodeInfo(maxi)<<" avec "<<max<<" autoroutes entrantes."<<endl<<endl;

    //B
    //LA METHODE Valide VERFIE SI LE GRAPHE A AU MOINS UNE ROUTE ENTRE DEUX VILLES
    if(g.Valide()==0)
        cout<<"La carte n'est pas valide."<<endl<<endl;
    else
        cout<<"La carte est valide."<<endl<<endl;

    //C
    //LA METHODE Inaccessible AFFICHE LES VILLES AUXQUELLES ON NE PEUT PAS ARRIVER DIRECTEMENT DEPUIS UNE CERTAINE VILLE, CAR ON N'A PAS UNE AUTOROUTE SORTANTE VERS ELLES
    for(i=0;i<nv;i++)
    {
        cout<<"Les villes inaccessibles pour "<<g.getNodeInfo(i)<<" sont: ";
        g.Inaccessible(g.getNodeInfo(i));
        cout<<endl;
    }

    //D
    int nss,nov;
    f>>nss; //NOMBRE STATIONS SERVICE
    ss=new char[nv]; //VECTEUR AVEC DES VALEURS DE 0 (POUR LES VILLES QUI NE SONT PAS STATIONS SERVICE) ET 1 (POUR LES VILLES QUI SONT DES STATIONS SERVICE)
    for(i=0;i<nss;i++)
    {
        f>>a; //VILLE STATION SERVICE
        j=0;
        while(g.getNodeInfo(j)!=a && j<nv)
            j++;
        ss[j]=1;
    }

    f>>nov; //NOMBRES VOITURES
    voiture v[nov]; //VECTEUR QUI RETIENT LES VOITURES QUI ONT BESOIN D'UN STATION SERVICE, INCLUANT LEUR POSITION INITIALE, LEUR QUANTITE DE GAZ INITIALE ET COMBIEN DU GAZ ELLES CONSUMMENT POUR VOYAGER DEPUIS UNE VILLE VERS UNE AUTRE
    for(i=0;i<nov;i++)
        f>>v[i].ville>>v[i].gaz>>v[i].cons;

    for(i=0;i<nov;i++)
    {
        j=0;k=1;
        //ON VA PARCOURIR LE GRAPHE POUR TROUVER LA PLUS PROCHE STATION SERVICE A L'AIDE DE L'ALGORITHME DEPTH-FIRST (DF)
        //A L'INTERIEUR DE LA METHODE DF ON A UN VECTEUR visited, QUI MARQUE LES VILLES VISITEES (EN AJOUTANT UNE VALEUR DE 1) ET UN VECTEUR ord QUI RETIENT L'ORDRE DE PARCOURS ET LE GAZ RESTANT APRES CHAQUE PAS EFFECTUE
        //C'EST POUR CELA QU'ON DOIT LES REINITIALISER POUR CHAQUE VOITURE
        g.refaire_visited_ord();

        //ON CHERCHE DANS NOTRE GRAPHE LA POSITION DE LA VILLE
        while(g.getNodeInfo(j)!=v[i].ville)
            j++;

        cout<<endl<<"Depuis "<<v[i].ville<<" on peut voyager comme ca: ";
        //ON TRANSMET COMME PARAMETRES L'INDEX DE LA VILLE INITIALE, LA POSITION DE COMMENCEMENT POUR LE VECTEUR ord, SA QUANTITE DE GAZ INITIALE ET LA CONSOMMATION
        g.DF(j,0,v[i].gaz,v[i].cons);
        cout<<endl;


        while(g.ord[k].index!=-1 && k<nv) //ON PARCOURT LE VECTEUR ord
        {
            if(ss[g.ord[k].index]==1) // SI LA VILLE EST AUSSI UNE STATION SERVICE...
            {
                if(g.ord[k].combustibil>0) //...ET LE GAZ EST SUFFISANT POUR Y ARRIVER...
                    cout<<"La station service est "<<g.getNodeInfo(g.ord[k].index); // ...ON A TROUVER NOTRE REPONSE
                else
                    cout<<"Cette voiture ne peut pas arriver a une station service"; // SINON, ON N'AS PAS DE SOLUTION
                break;
            }
            k++;
        }
        cout<<endl;
    }

    f.close();
    return 0;
}
