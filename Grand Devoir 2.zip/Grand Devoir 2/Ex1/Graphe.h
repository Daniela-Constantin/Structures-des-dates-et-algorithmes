#ifndef GRAPHE_H_INCLUDED
#define GRAPHE_H_INCLUDED

#include <queue>
#include <iostream>
using namespace std;

struct str_ord
{
    int index;
    int combustibil;
};

template<typename TnodeInfo, typename TedgeInfo>
class Graph {
    public:
        int* visited;
        str_ord *ord;
        int N,j;
        char **A;
        TnodeInfo *nodeInfo;
        TedgeInfo **edgeInfo;

        Graph(int numNodes)
        {
            int i, j;

            N = numNodes;

            A = new char*[N];
            for (i = 0; i < N; i++)
                A[i] = new char[N];
			for (i = 0; i < N; i++)
                for (j = 0; j < N; j++)
                    A[i][j] = 0;

            nodeInfo = new TnodeInfo[N];

            edgeInfo = new TedgeInfo*[N];
            for (i = 0; i < N; i++)
                edgeInfo[i] = new TedgeInfo[N];
        }

        void setNodeInfo(int i, TnodeInfo info)
        {
            nodeInfo[i] = info;
        }

        TnodeInfo getNodeInfo(int i)
        {
            return nodeInfo[i];
        }

        void addEdge(int i, int j)
        {
            A[i][j] = 1;
        }
        void removeEdge(int i, int j)
        {
            A[i][j]  = 0;
        }

        void setEdgeInfo(int i, int j, TedgeInfo info)
        {
            edgeInfo[i][j] = info;
        }

        TedgeInfo getEdgeInfo(int i, int j)
        {
            return edgeInfo[i][j];
        }

        //A
        int Grad(int i)
        {
            int nr=0;
            for(int j=0;j<N;j++)
                if(i!=j && A[j][i]==1)
                    nr++;
             return nr;
        }

        //B
        int Valide()
        {
            for(int i=0;i<N;i++)
                for(int j=0;j<N;j++)
                    if(A[i][j]==0 && A[j][i]==0 && i!=j)
                        return 0;
            return 1;
        }

        //C
        void Inaccessible(TnodeInfo i)
        {
            int j=0;
            while(nodeInfo[j]!=i)
                        j++;
            for(int k=0;k<N;k++)
                if(A[j][k]!=1 && A[k][j]!=1 && j!=k)
                    cout<<nodeInfo[k]<<" ";
        }

        //D
        void refaire_visited_ord()
        {
            ord=new str_ord[N];
            visited=new int[N];
            for(int i=0;i<N;i++)
            {
                visited[i]=0;
                ord[i].index=-1;
                ord[i].combustibil=0;
            }
        }

        void DF(int x, int j, int a, int b)
        {
            int i;
            ord[j].index=x;
            ord[j].combustibil=a-j*b;
            visited[x]=1;
            cout<<nodeInfo[x]<<" ";
            for(i=0;i<N;i++)
                if(A[x][i]==1 && visited[i]==0)
                    DF(i,j+1,a,b);
        }

        ~Graph()
        {
            int i;
            for (i = 0; i < N; i++)
            {
                delete A[i];
                delete edgeInfo[i];
            }
            delete A;
            delete edgeInfo;
            delete nodeInfo;
        }
};


#endif // GRAPHE_H_INCLUDED
